create database workersdatabase
go
use workersdatabase
create table employes_data
(
id_employe int not null primary key identity (1,1),
firstname varchar(50) not null,
lastname varchar(50) not null,
dui varchar(15) not null,
phone varchar(12) not null,
job varchar(150) not null,
contract_date varchar(10) not null,
salary varchar(10) not null
);
create table form_employe
(
id_form int not null primary key identity (1,1), 
id_employe_fore int foreign key references employes_data (id_employe),
salary varchar(20) not null,
bonus_salary varchar(20),
discount_salary varchar(20),
time_count varchar(10),
);
