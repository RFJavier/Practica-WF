﻿using employecountsystem.bussines;
using employecountsystem.entities;
using employecountsystem.Utilidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace employecountsystem
{
    public partial class Modificar_Datos_de_Usuario : Form
    {
        public Modificar_Datos_de_Usuario()
        {
            InitializeComponent();
        }
        employees employees = new employees();
        public int _idemployee;

        private void cargardatos()
        {
            employees = employee_data1.buscarporid(_idemployee);
            if (employees.Id_employee > 0)
            {
                textBox1.Text = employees.Id_employee.ToString();
                firstname.Text = employees.firstname;
                lastname.Text = employees.lastname;
                dui.Text = employees.DUI;
                phone.Text = employees.phone;
                job.Text = employees.job;
                contract_date.Text = employees.contract_date;
                salary.Text = employees.salary;


            }
            else
            {
                MessageBox.Show("ocurrio un problema al cargar datos");
                this.Close();
            }
        }

        private void Modificar_Datos_de_Usuario_Load(object sender, EventArgs e)
        {
            cargardatos();
        }

        private void Modify_Click(object sender, EventArgs e)
        {
            employees.firstname = firstname.Text;
            employees.lastname = lastname.Text;
            employees.DUI = dui.Text;
            employees.phone = phone.Text;
            employees.job = job.Text;
            employees.contract_date = contract_date.Text;
            employees.salary = salary.Text;
            if (employee_data1.modificar(employees) > 0)
            {
                MessageBox.Show("registro exitoso");
                this.Close();
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Eliminar_Click(object sender, EventArgs e)
        {

        }
    }
}
