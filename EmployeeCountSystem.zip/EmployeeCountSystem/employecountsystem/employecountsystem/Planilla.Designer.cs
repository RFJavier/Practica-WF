﻿namespace employecountsystem
{
    partial class Planilla
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            Eliminar = new Button();
            ModifyEmploye = new Button();
            dataGridView1 = new DataGridView();
            menuStrip1 = new MenuStrip();
            principalToolStripMenuItem = new ToolStripMenuItem();
            empleadosToolStripMenuItem = new ToolStripMenuItem();
            nuevoToolStripMenuItem = new ToolStripMenuItem();
            baseDeDatosToolStripMenuItem1 = new ToolStripMenuItem();
            planillaToolStripMenuItem = new ToolStripMenuItem();
            nuevoToolStripMenuItem1 = new ToolStripMenuItem();
            baseDeDatosToolStripMenuItem2 = new ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = SystemColors.Info;
            button1.Location = new Point(562, 216);
            button1.Name = "button1";
            button1.Size = new Size(245, 89);
            button1.TabIndex = 9;
            button1.Text = "Nuevo";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Eliminar
            // 
            Eliminar.BackColor = SystemColors.Info;
            Eliminar.Location = new Point(198, 216);
            Eliminar.Name = "Eliminar";
            Eliminar.Size = new Size(245, 89);
            Eliminar.TabIndex = 8;
            Eliminar.Text = "Eliminar";
            Eliminar.UseVisualStyleBackColor = false;
            Eliminar.Click += Eliminar_Click;
            // 
            // ModifyEmploye
            // 
            ModifyEmploye.BackColor = SystemColors.Info;
            ModifyEmploye.Location = new Point(0, 216);
            ModifyEmploye.Name = "ModifyEmploye";
            ModifyEmploye.Size = new Size(201, 89);
            ModifyEmploye.TabIndex = 7;
            ModifyEmploye.Text = "Modificar";
            ModifyEmploye.UseVisualStyleBackColor = false;
            ModifyEmploye.Click += ModifyEmploye_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = SystemColors.ButtonHighlight;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(0, 31);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.RowTemplate.Height = 29;
            dataGridView1.Size = new Size(807, 188);
            dataGridView1.TabIndex = 5;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { principalToolStripMenuItem, empleadosToolStripMenuItem, planillaToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(808, 28);
            menuStrip1.TabIndex = 6;
            menuStrip1.Text = "menuStrip1";
            // 
            // principalToolStripMenuItem
            // 
            principalToolStripMenuItem.Name = "principalToolStripMenuItem";
            principalToolStripMenuItem.Size = new Size(80, 24);
            principalToolStripMenuItem.Text = "Principal";
            // 
            // empleadosToolStripMenuItem
            // 
            empleadosToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { nuevoToolStripMenuItem, baseDeDatosToolStripMenuItem1 });
            empleadosToolStripMenuItem.Name = "empleadosToolStripMenuItem";
            empleadosToolStripMenuItem.Size = new Size(97, 24);
            empleadosToolStripMenuItem.Text = "Empleados";
            // 
            // nuevoToolStripMenuItem
            // 
            nuevoToolStripMenuItem.Name = "nuevoToolStripMenuItem";
            nuevoToolStripMenuItem.Size = new Size(187, 26);
            nuevoToolStripMenuItem.Text = "Nuevo";
            // 
            // baseDeDatosToolStripMenuItem1
            // 
            baseDeDatosToolStripMenuItem1.Name = "baseDeDatosToolStripMenuItem1";
            baseDeDatosToolStripMenuItem1.Size = new Size(187, 26);
            baseDeDatosToolStripMenuItem1.Text = "Base de Datos";
            // 
            // planillaToolStripMenuItem
            // 
            planillaToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { nuevoToolStripMenuItem1, baseDeDatosToolStripMenuItem2 });
            planillaToolStripMenuItem.Name = "planillaToolStripMenuItem";
            planillaToolStripMenuItem.Size = new Size(71, 24);
            planillaToolStripMenuItem.Text = "Planilla";
            // 
            // nuevoToolStripMenuItem1
            // 
            nuevoToolStripMenuItem1.Name = "nuevoToolStripMenuItem1";
            nuevoToolStripMenuItem1.Size = new Size(185, 26);
            nuevoToolStripMenuItem1.Text = "Nuevo";
            // 
            // baseDeDatosToolStripMenuItem2
            // 
            baseDeDatosToolStripMenuItem2.Name = "baseDeDatosToolStripMenuItem2";
            baseDeDatosToolStripMenuItem2.Size = new Size(185, 26);
            baseDeDatosToolStripMenuItem2.Text = "Base de datos";
            // 
            // Planilla
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(808, 306);
            Controls.Add(button1);
            Controls.Add(Eliminar);
            Controls.Add(ModifyEmploye);
            Controls.Add(dataGridView1);
            Controls.Add(menuStrip1);
            Name = "Planilla";
            Text = "Planilla";
            Load += Planilla_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button Eliminar;
        private Button ModifyEmploye;
        private DataGridView dataGridView1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem principalToolStripMenuItem;
        private ToolStripMenuItem empleadosToolStripMenuItem;
        private ToolStripMenuItem nuevoToolStripMenuItem;
        private ToolStripMenuItem baseDeDatosToolStripMenuItem1;
        private ToolStripMenuItem planillaToolStripMenuItem;
        private ToolStripMenuItem nuevoToolStripMenuItem1;
        private ToolStripMenuItem baseDeDatosToolStripMenuItem2;
    }
}