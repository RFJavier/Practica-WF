﻿namespace employecountsystem
{
    partial class agregar__planilla
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            DataEmployee = new Button();
            horas = new TextBox();
            descuento = new TextBox();
            bonus = new TextBox();
            salario = new TextBox();
            NuevoEmpleado = new Button();
            SuspendLayout();
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(8, 111);
            label4.Name = "label4";
            label4.Size = new Size(118, 20);
            label4.TabIndex = 29;
            label4.Text = "Conteo de horas";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(8, 78);
            label3.Name = "label3";
            label3.Size = new Size(79, 20);
            label3.TabIndex = 28;
            label3.Text = "Descuento";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(8, 45);
            label2.Name = "label2";
            label2.Size = new Size(49, 20);
            label2.TabIndex = 27;
            label2.Text = "bonus";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(10, 9);
            label1.Name = "label1";
            label1.Size = new Size(55, 20);
            label1.TabIndex = 26;
            label1.Text = "Salario";
            // 
            // DataEmployee
            // 
            DataEmployee.BackColor = SystemColors.Info;
            DataEmployee.Location = new Point(472, 13);
            DataEmployee.Name = "DataEmployee";
            DataEmployee.Size = new Size(211, 125);
            DataEmployee.TabIndex = 25;
            DataEmployee.Text = "Datos de Planilla";
            DataEmployee.UseVisualStyleBackColor = false;
            DataEmployee.Click += DataEmployee_Click;
            // 
            // horas
            // 
            horas.BackColor = SystemColors.Menu;
            horas.Location = new Point(171, 111);
            horas.Name = "horas";
            horas.Size = new Size(270, 27);
            horas.TabIndex = 21;
            // 
            // descuento
            // 
            descuento.BackColor = SystemColors.Menu;
            descuento.Location = new Point(171, 78);
            descuento.Name = "descuento";
            descuento.Size = new Size(270, 27);
            descuento.TabIndex = 20;
            // 
            // bonus
            // 
            bonus.BackColor = SystemColors.Menu;
            bonus.Location = new Point(171, 45);
            bonus.Name = "bonus";
            bonus.Size = new Size(270, 27);
            bonus.TabIndex = 19;
            // 
            // salario
            // 
            salario.BackColor = SystemColors.Menu;
            salario.Location = new Point(171, 12);
            salario.Name = "salario";
            salario.Size = new Size(270, 27);
            salario.TabIndex = 18;
            // 
            // NuevoEmpleado
            // 
            NuevoEmpleado.BackColor = SystemColors.Info;
            NuevoEmpleado.Location = new Point(472, 144);
            NuevoEmpleado.Name = "NuevoEmpleado";
            NuevoEmpleado.Size = new Size(211, 85);
            NuevoEmpleado.TabIndex = 17;
            NuevoEmpleado.Text = "Nuevo";
            NuevoEmpleado.UseVisualStyleBackColor = false;
            NuevoEmpleado.Click += NuevoEmpleado_Click;
            // 
            // agregar__planilla
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(692, 247);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(DataEmployee);
            Controls.Add(horas);
            Controls.Add(descuento);
            Controls.Add(bonus);
            Controls.Add(salario);
            Controls.Add(NuevoEmpleado);
            Name = "agregar__planilla";
            Text = "agregar__planilla";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button DataEmployee;
        private TextBox horas;
        private TextBox descuento;
        private TextBox bonus;
        private TextBox salario;
        private Button NuevoEmpleado;
    }
}