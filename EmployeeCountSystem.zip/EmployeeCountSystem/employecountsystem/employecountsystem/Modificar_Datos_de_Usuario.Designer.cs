﻿namespace employecountsystem
{
    partial class Modificar_Datos_de_Usuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            salary = new TextBox();
            contract_date = new TextBox();
            job = new TextBox();
            phone = new TextBox();
            dui = new TextBox();
            lastname = new TextBox();
            firstname = new TextBox();
            Modify = new Button();
            textBox1 = new TextBox();
            label8 = new Label();
            SuspendLayout();
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(10, 210);
            label7.Name = "label7";
            label7.Size = new Size(55, 20);
            label7.TabIndex = 30;
            label7.Text = "Salario";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(10, 177);
            label6.Name = "label6";
            label6.Size = new Size(157, 20);
            label6.TabIndex = 29;
            label6.Text = "Fecha de Contratacion";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(10, 144);
            label5.Name = "label5";
            label5.Size = new Size(128, 20);
            label5.TabIndex = 28;
            label5.Text = "Puesto de Trabajo";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(10, 111);
            label4.Name = "label4";
            label4.Size = new Size(67, 20);
            label4.TabIndex = 27;
            label4.Text = "Telefono";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(10, 78);
            label3.Name = "label3";
            label3.Size = new Size(34, 20);
            label3.TabIndex = 26;
            label3.Text = "DUI";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(10, 45);
            label2.Name = "label2";
            label2.Size = new Size(72, 20);
            label2.TabIndex = 25;
            label2.Text = "Apellidos";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(70, 20);
            label1.TabIndex = 24;
            label1.Text = "Nombres";
            // 
            // salary
            // 
            salary.BackColor = SystemColors.Menu;
            salary.Location = new Point(173, 210);
            salary.Name = "salary";
            salary.Size = new Size(270, 27);
            salary.TabIndex = 23;
            // 
            // contract_date
            // 
            contract_date.BackColor = SystemColors.Menu;
            contract_date.Location = new Point(173, 177);
            contract_date.Name = "contract_date";
            contract_date.Size = new Size(270, 27);
            contract_date.TabIndex = 22;
            // 
            // job
            // 
            job.BackColor = SystemColors.Menu;
            job.Location = new Point(173, 144);
            job.Name = "job";
            job.Size = new Size(270, 27);
            job.TabIndex = 21;
            // 
            // phone
            // 
            phone.BackColor = SystemColors.Menu;
            phone.Location = new Point(173, 111);
            phone.Name = "phone";
            phone.Size = new Size(270, 27);
            phone.TabIndex = 20;
            // 
            // dui
            // 
            dui.BackColor = SystemColors.Menu;
            dui.Location = new Point(173, 78);
            dui.Name = "dui";
            dui.Size = new Size(270, 27);
            dui.TabIndex = 19;
            // 
            // lastname
            // 
            lastname.BackColor = SystemColors.Menu;
            lastname.Location = new Point(173, 45);
            lastname.Name = "lastname";
            lastname.Size = new Size(270, 27);
            lastname.TabIndex = 18;
            // 
            // firstname
            // 
            firstname.BackColor = SystemColors.Menu;
            firstname.Location = new Point(173, 12);
            firstname.Name = "firstname";
            firstname.Size = new Size(270, 27);
            firstname.TabIndex = 17;
            // 
            // Modify
            // 
            Modify.BackColor = SystemColors.Info;
            Modify.Location = new Point(10, 276);
            Modify.Name = "Modify";
            Modify.Size = new Size(433, 85);
            Modify.TabIndex = 31;
            Modify.Text = "Modificar";
            Modify.UseVisualStyleBackColor = false;
            Modify.Click += Modify_Click;
            // 
            // textBox1
            // 
            textBox1.BackColor = SystemColors.Menu;
            textBox1.Location = new Point(173, 243);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(125, 27);
            textBox1.TabIndex = 32;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(304, 246);
            label8.Name = "label8";
            label8.Size = new Size(94, 20);
            label8.TabIndex = 33;
            label8.Text = "Id Empleado";
            // 
            // Modificar_Datos_de_Usuario
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(451, 370);
            Controls.Add(label8);
            Controls.Add(textBox1);
            Controls.Add(Modify);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(salary);
            Controls.Add(contract_date);
            Controls.Add(job);
            Controls.Add(phone);
            Controls.Add(dui);
            Controls.Add(lastname);
            Controls.Add(firstname);
            Name = "Modificar_Datos_de_Usuario";
            Text = "Modificar_Datos_de_Usuario";
            Load += Modificar_Datos_de_Usuario_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox salary;
        private TextBox contract_date;
        private TextBox job;
        private TextBox phone;
        private TextBox dui;
        private TextBox lastname;
        private TextBox firstname;
        private Button Modify;
        private TextBox textBox1;
        private Label label8;
    }
}