﻿using employecountsystem.bussines;
using employecountsystem.entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace employecountsystem
{
    public partial class agregar__planilla : Form
    {
        public agregar__planilla()
        {
            InitializeComponent();
        }

        form forms = new form();
        public int _idform = 0;


        private bool validardatosformulario()
        {
            bool validar = false;

            if (salario.Text.Trim().Equals(""))
            {
                MessageBox.Show("nombres de Trabajador esta vacio");
                validar = true;
            }
            if (bonus.Text.Trim().Equals(""))
            {
                MessageBox.Show("Apellidos de trabajador esta vacio");
                validar = true;
            }
            if (descuento.Text.Trim().Equals(""))
            {
                MessageBox.Show("DUI de trabajador esta vacio");
                validar = true;
            }
            if (horas.Text.Trim().Equals(""))
            {
                MessageBox.Show("Numero de contacto esta vacio");
                validar = true;
            }

            return validar;

        }
        private void guardar()
        {
            try
            {
                if (!validardatosformulario())
                {
                    forms.salary = salario.Text;
                    forms.bonus_salary = bonus.Text;
                    forms.discount_salary = descuento.Text;
                    forms.time_count = horas.Text;

                    if (_idform <= 0)
                    {
                        if (form_data1.save(forms) > 0)
                        {
                            MessageBox.Show("registro exitoso");


                        }
                    }


                }

            }
            catch (Exception)
            {
                MessageBox.Show("ocurrio un error al intentar guardar");

            }


        }
        private void NuevoEmpleado_Click(object sender, EventArgs e)
        {
            guardar();
        }

        private void DataEmployee_Click(object sender, EventArgs e)
        {
            planilladatos datos_ = new planilladatos();
            datos_.StartPosition = FormStartPosition.CenterScreen;
            datos_.ShowDialog();
        }
    }
}
