﻿namespace employecountsystem
{
    partial class planilla_modificar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label8 = new Label();
            textBox1 = new TextBox();
            Modify = new Button();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            count_time = new TextBox();
            desc_salary = new TextBox();
            bonus_salary = new TextBox();
            salario = new TextBox();
            fore = new TextBox();
            SuspendLayout();
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(306, 152);
            label8.Name = "label8";
            label8.Size = new Size(94, 20);
            label8.TabIndex = 50;
            label8.Text = "Id Empleado";
            // 
            // textBox1
            // 
            textBox1.BackColor = SystemColors.Menu;
            textBox1.Location = new Point(175, 149);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(125, 27);
            textBox1.TabIndex = 49;
            // 
            // Modify
            // 
            Modify.BackColor = SystemColors.Info;
            Modify.Location = new Point(12, 182);
            Modify.Name = "Modify";
            Modify.Size = new Size(433, 85);
            Modify.TabIndex = 48;
            Modify.Text = "Modificar";
            Modify.UseVisualStyleBackColor = false;
            Modify.Click += Modify_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 118);
            label4.Name = "label4";
            label4.Size = new Size(116, 20);
            label4.TabIndex = 44;
            label4.Text = "conteo de horas";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 85);
            label3.Name = "label3";
            label3.Size = new Size(79, 20);
            label3.TabIndex = 43;
            label3.Text = "Descuento";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 52);
            label2.Name = "label2";
            label2.Size = new Size(49, 20);
            label2.TabIndex = 42;
            label2.Text = "Bonus";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(14, 16);
            label1.Name = "label1";
            label1.Size = new Size(53, 20);
            label1.TabIndex = 41;
            label1.Text = "salario";
            // 
            // count_time
            // 
            count_time.BackColor = SystemColors.Menu;
            count_time.Location = new Point(175, 118);
            count_time.Name = "count_time";
            count_time.Size = new Size(270, 27);
            count_time.TabIndex = 37;
            // 
            // desc_salary
            // 
            desc_salary.BackColor = SystemColors.Menu;
            desc_salary.Location = new Point(175, 85);
            desc_salary.Name = "desc_salary";
            desc_salary.Size = new Size(270, 27);
            desc_salary.TabIndex = 36;
            // 
            // bonus_salary
            // 
            bonus_salary.BackColor = SystemColors.Menu;
            bonus_salary.Location = new Point(175, 52);
            bonus_salary.Name = "bonus_salary";
            bonus_salary.Size = new Size(270, 27);
            bonus_salary.TabIndex = 35;
            // 
            // salario
            // 
            salario.BackColor = SystemColors.Menu;
            salario.Location = new Point(175, 19);
            salario.Name = "salario";
            salario.Size = new Size(270, 27);
            salario.TabIndex = 34;
            // 
            // fore
            // 
            fore.BackColor = SystemColors.Menu;
            fore.Location = new Point(25, 145);
            fore.Name = "fore";
            fore.Size = new Size(125, 27);
            fore.TabIndex = 51;
            fore.TextChanged += fore_TextChanged;
            // 
            // planilla_modificar
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(453, 273);
            Controls.Add(fore);
            Controls.Add(label8);
            Controls.Add(textBox1);
            Controls.Add(Modify);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(count_time);
            Controls.Add(desc_salary);
            Controls.Add(bonus_salary);
            Controls.Add(salario);
            Name = "planilla_modificar";
            Text = "planilla_modificar";
            Load += planilla_modificar_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label8;
        private TextBox textBox1;
        private Button Modify;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox count_time;
        private TextBox desc_salary;
        private TextBox bonus_salary;
        private TextBox salario;
        private TextBox fore;
    }
}