﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace employecountsystem
{
    public partial class index1 : Form
    {
        public index1()
        {
            InitializeComponent();
        }

        private void baseDeDatosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Datos employee_ = new Datos();
            employee_.StartPosition = FormStartPosition.CenterScreen;
            employee_.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Principal datos_ = new Principal();
            datos_.StartPosition = FormStartPosition.CenterScreen;
            datos_.ShowDialog();
        }

        private void empleadosToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void nuevoToolStripMenuItem_Click(object sender, EventArgs e)
        {

            index datos_ = new index();
            datos_.StartPosition = FormStartPosition.CenterScreen;
            datos_.ShowDialog();
        }

        private void principalToolStripMenuItem_Click(object sender, EventArgs e)
        {

            index1 datos_ = new index1();
            datos_.StartPosition = FormStartPosition.CenterScreen;
            datos_.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Planilla datos_ = new Planilla();
            datos_.StartPosition = FormStartPosition.CenterScreen;
            datos_.ShowDialog();
        }

        private void nuevoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            agregar__planilla datos_ = new agregar__planilla();
            datos_.StartPosition = FormStartPosition.CenterScreen;
            datos_.ShowDialog();
        }

        private void baseDeDatosToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            planilladatos datos_ = new planilladatos();
            datos_.StartPosition = FormStartPosition.CenterScreen;
            datos_.ShowDialog();
        }
    }
}
