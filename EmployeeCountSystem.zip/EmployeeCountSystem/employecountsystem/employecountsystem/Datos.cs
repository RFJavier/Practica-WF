﻿using employecountsystem.bussines;
using employecountsystem.entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace employecountsystem
{
    public partial class Datos : Form
    {

        public Datos()
        {
            InitializeComponent();
        }
        employees employees = new employees();
        public int _idemployee = 0;
        private void cargardatos()
        {
            employees = employee_data1.buscarporid(_idemployee);
            if (employees.Id_employee >= 0)
            {
                dataGridView1.DataSource = employee_data1.obtenertodos();
            }
            else
            {
                MessageBox.Show("ocurrio un problema al cargar datos");
                this.Close();
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            cargardatos();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
