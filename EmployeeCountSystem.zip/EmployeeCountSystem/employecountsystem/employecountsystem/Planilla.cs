﻿using employecountsystem.bussines;
using employecountsystem.DAL;
using employecountsystem.entities;
using employecountsystem.Utilidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace employecountsystem
{
    public partial class Planilla : Form
    {
        public Planilla()
        {
            InitializeComponent();
        }
        form forms = new form();
        public int _idform;
        public string _id;
        private void Planilla_Load(object sender, EventArgs e)
        {
            mostrar();
        }
        private void mostrar()
        {
            dataGridView1.DataSource = form_data1.obtenertodos();
        }

        private void ModifyEmploye_Click(object sender, EventArgs e)
        {
            int id = uformulario.obtenerdgrid(dataGridView1);
            if (id > 0)
            {
                planilla_modificar datos_ = new planilla_modificar();
                datos_.StartPosition = FormStartPosition.CenterScreen;
                datos_._idform = id;
                datos_.ShowDialog();
                mostrar();

            }
            else
            {
                MessageBox.Show("debe seleccionar un registro");
            }
        }

        private void Eliminar_Click(object sender, EventArgs e)
        {
            int id = uformulario.obtenerdgrid(dataGridView1);
            if (id > 0)
            {
                if (MessageBox.Show("desea eliminar el registro?", "eliminar",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                {
                    if (form_data1.eliminar(new form { id_form = id }) > 0)
                    {
                        MessageBox.Show("registro eliminado");
                        mostrar();
                    }
                    else
                    {
                        MessageBox.Show("No se ah eliminado el registro");
                    }

                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            agregar__planilla datos_ = new agregar__planilla();
            datos_.StartPosition = FormStartPosition.CenterScreen;
            datos_.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
