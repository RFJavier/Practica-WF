﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using employecountsystem.bussines;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using employecountsystem.entities;
using employecountsystem;
namespace employecountsystem
{
    public partial class index : Form
    {
        public index()
        {
            InitializeComponent();
        }
        employees employees = new employees();
        public int _idemployee = 0;


        private bool validardatosformulario()
        {
            bool validar = false;

            if (firstname.Text.Trim().Equals(""))
            {
                MessageBox.Show("nombres de Trabajador esta vacio");
                validar = true;
            }
            if (lastname.Text.Trim().Equals(""))
            {
                MessageBox.Show("Apellidos de trabajador esta vacio");
                validar = true;
            }
            if (dui.Text.Trim().Equals(""))
            {
                MessageBox.Show("DUI de trabajador esta vacio");
                validar = true;
            }
            if (phone.Text.Trim().Equals(""))
            {
                MessageBox.Show("Numero de contacto esta vacio");
                validar = true;
            }
            if (job.Text.Trim().Equals(""))
            {
                MessageBox.Show("No ah declarado un puesto de trabajo");
                validar = true;
            }
            if (contract_date.Text.Trim().Equals(""))
            {
                MessageBox.Show("No ah ingresado un fecha de contratacion");
                validar = true;
            }
            if (salary.Text.Trim().Equals(""))
            {
                MessageBox.Show("No ah declarado el salario del trabajador");
                validar = true;
            }
            return validar;

        }
        private void guardar()
        {
            try
            {
                if (!validardatosformulario())
                {
                    employees.firstname = firstname.Text;
                    employees.lastname = lastname.Text;
                    employees.DUI = dui.Text;
                    employees.phone = phone.Text;
                    employees.job = job.Text;
                    employees.contract_date = contract_date.Text;
                    employees.salary = salary.Text;
                    if (_idemployee <= 0)
                    {
                        if (employee_data1.save(employees) > 0)
                        {
                            MessageBox.Show("registro exitoso");


                        }
                    }


                }

            }
            catch (Exception)
            {
                MessageBox.Show("ocurrio un error al intentar guardar");

            }


        }

        private void Modificardatos_Click(object sender, EventArgs e)
        {

        }

        private void NuevoEmpleado_Click(object sender, EventArgs e)
        {
            //estadosproveedor estadosproveedor = new estadosproveedor();
            //estadosproveedor.StartPosition = FormStartPosition.CenterScreen;
            //estadosproveedor.ShowDialog();
            //mostrarproveedor();
            guardar();

        }
        //private void mostrar_datos()
        //{
        //    Obtainall.DataSource = employee_data1.obtenertodos();


        //}
        private void Obtainall_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void index_Load(object sender, EventArgs e)
        {


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void firstname_TextChanged(object sender, EventArgs e)
        {

        }

        private void DataEmployee_Click(object sender, EventArgs e)
        {
            Datos employee_ = new Datos();
            employee_.StartPosition = FormStartPosition.CenterScreen;
            employee_.ShowDialog();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void BuscarId_Click(object sender, EventArgs e)
        {
            //employee_data1.buscarporid(_idemployee);

            //employees = employee_data1.buscarporid(_idemployee);
            //if (employees.Id_employee > 0)
            //{
            //    textBox1.Text = employees.Id_employee.ToString();
            //    firstname.Text = employees.firstname;
            //    lastname.Text = employees.lastname;
            //    dui.Text = employees.DUI;
            //    phone.Text = employees.phone;
            //    job.Text = employees.job;
            //    contract_date.Text = employees.contract_date;
            //    salary.Text = employees.salary;
            //}
            //else
            //{
            //    MessageBox.Show("ocurrio un problema al cargar datos");
            //    this.Close();
            //}
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {
        }

        private void label4_Click(object sender, EventArgs e)
        {
        }

        private void label3_Click(object sender, EventArgs e)
        {
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void salary_TextChanged(object sender, EventArgs e)
        {
        }

        private void contract_date_TextChanged(object sender, EventArgs e)
        {
        }

        private void job_TextChanged(object sender, EventArgs e)
        {
        }

        private void phone_TextChanged(object sender, EventArgs e)
        {
        }

        private void dui_TextChanged(object sender, EventArgs e)
        {
        }

        private void lastname_TextChanged(object sender, EventArgs e)
        {
        }

        private void label7_Click(object sender, EventArgs e)
        {
        }
    }
}
