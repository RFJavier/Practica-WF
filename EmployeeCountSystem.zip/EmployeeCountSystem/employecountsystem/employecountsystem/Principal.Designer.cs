﻿namespace employecountsystem
{
    partial class Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            menuStrip1 = new MenuStrip();
            principalToolStripMenuItem = new ToolStripMenuItem();
            empleadosToolStripMenuItem = new ToolStripMenuItem();
            nuevoToolStripMenuItem = new ToolStripMenuItem();
            baseDeDatosToolStripMenuItem1 = new ToolStripMenuItem();
            planillaToolStripMenuItem = new ToolStripMenuItem();
            nuevoToolStripMenuItem1 = new ToolStripMenuItem();
            baseDeDatosToolStripMenuItem2 = new ToolStripMenuItem();
            ModifyEmploye = new Button();
            Eliminar = new Button();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = SystemColors.ButtonHighlight;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(0, 31);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.RowTemplate.Height = 29;
            dataGridView1.Size = new Size(1053, 188);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { principalToolStripMenuItem, empleadosToolStripMenuItem, planillaToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1057, 28);
            menuStrip1.TabIndex = 1;
            menuStrip1.Text = "menuStrip1";
            // 
            // principalToolStripMenuItem
            // 
            principalToolStripMenuItem.Name = "principalToolStripMenuItem";
            principalToolStripMenuItem.Size = new Size(80, 24);
            principalToolStripMenuItem.Text = "Principal";
            principalToolStripMenuItem.Click += principalToolStripMenuItem_Click;
            // 
            // empleadosToolStripMenuItem
            // 
            empleadosToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { nuevoToolStripMenuItem, baseDeDatosToolStripMenuItem1 });
            empleadosToolStripMenuItem.Name = "empleadosToolStripMenuItem";
            empleadosToolStripMenuItem.Size = new Size(97, 24);
            empleadosToolStripMenuItem.Text = "Empleados";
            // 
            // nuevoToolStripMenuItem
            // 
            nuevoToolStripMenuItem.Name = "nuevoToolStripMenuItem";
            nuevoToolStripMenuItem.Size = new Size(187, 26);
            nuevoToolStripMenuItem.Text = "Nuevo";
            nuevoToolStripMenuItem.Click += nuevoToolStripMenuItem_Click;
            // 
            // baseDeDatosToolStripMenuItem1
            // 
            baseDeDatosToolStripMenuItem1.Name = "baseDeDatosToolStripMenuItem1";
            baseDeDatosToolStripMenuItem1.Size = new Size(187, 26);
            baseDeDatosToolStripMenuItem1.Text = "Base de Datos";
            baseDeDatosToolStripMenuItem1.Click += baseDeDatosToolStripMenuItem1_Click;
            // 
            // planillaToolStripMenuItem
            // 
            planillaToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { nuevoToolStripMenuItem1, baseDeDatosToolStripMenuItem2 });
            planillaToolStripMenuItem.Name = "planillaToolStripMenuItem";
            planillaToolStripMenuItem.Size = new Size(71, 24);
            planillaToolStripMenuItem.Text = "Planilla";
            // 
            // nuevoToolStripMenuItem1
            // 
            nuevoToolStripMenuItem1.Name = "nuevoToolStripMenuItem1";
            nuevoToolStripMenuItem1.Size = new Size(224, 26);
            nuevoToolStripMenuItem1.Text = "Nuevo";
            nuevoToolStripMenuItem1.Click += nuevoToolStripMenuItem1_Click;
            // 
            // baseDeDatosToolStripMenuItem2
            // 
            baseDeDatosToolStripMenuItem2.Name = "baseDeDatosToolStripMenuItem2";
            baseDeDatosToolStripMenuItem2.Size = new Size(224, 26);
            baseDeDatosToolStripMenuItem2.Text = "Base de datos";
            baseDeDatosToolStripMenuItem2.Click += baseDeDatosToolStripMenuItem2_Click;
            // 
            // ModifyEmploye
            // 
            ModifyEmploye.BackColor = SystemColors.Info;
            ModifyEmploye.Location = new Point(0, 216);
            ModifyEmploye.Name = "ModifyEmploye";
            ModifyEmploye.Size = new Size(201, 89);
            ModifyEmploye.TabIndex = 2;
            ModifyEmploye.Text = "Modificar";
            ModifyEmploye.UseVisualStyleBackColor = false;
            ModifyEmploye.Click += ModifyEmploye_Click;
            // 
            // Eliminar
            // 
            Eliminar.BackColor = SystemColors.Info;
            Eliminar.Location = new Point(196, 216);
            Eliminar.Name = "Eliminar";
            Eliminar.Size = new Size(245, 89);
            Eliminar.TabIndex = 3;
            Eliminar.Text = "Eliminar";
            Eliminar.UseVisualStyleBackColor = false;
            Eliminar.Click += Eliminar_Click;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.Info;
            button1.Location = new Point(808, 216);
            button1.Name = "button1";
            button1.Size = new Size(245, 89);
            button1.TabIndex = 4;
            button1.Text = "Nuevo";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Principal
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1057, 308);
            Controls.Add(button1);
            Controls.Add(Eliminar);
            Controls.Add(ModifyEmploye);
            Controls.Add(dataGridView1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Principal";
            Text = "Empleado";
            Load += Index_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem principalToolStripMenuItem;
        private ToolStripMenuItem empleadosToolStripMenuItem;
        private ToolStripMenuItem planillaToolStripMenuItem;
        private ToolStripMenuItem nuevoToolStripMenuItem;
        private ToolStripMenuItem baseDeDatosToolStripMenuItem1;
        private ToolStripMenuItem nuevoToolStripMenuItem1;
        private ToolStripMenuItem baseDeDatosToolStripMenuItem2;
        private Button ModifyEmploye;
        private Button Eliminar;
        private Button button1;
    }
}