﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace employecountsystem.Utilidades
{
    public class uformulario
    {
        public static int obtenerdgrid(DataGridView datagridView)
        {
            try
            {
                int id = 0;
                id = int.Parse(datagridView.Rows[datagridView.CurrentRow.Index].Cells[0].Value.ToString());
                return id;
            }
            catch (Exception)
            {
                return 0;

            }
        }
    }
}
