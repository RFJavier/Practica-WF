﻿using employecountsystem.bussines;
using employecountsystem.entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace employecountsystem
{
    public partial class planilla_modificar : Form
    {
        public planilla_modificar()
        {
            InitializeComponent();
        }
        form forms = new form();
        public int _idform;
        private void Modify_Click(object sender, EventArgs e)
        {
            forms.salary = salario.Text;
            forms.bonus_salary = bonus_salary.Text;
            forms.discount_salary = desc_salary.Text;
            forms.time_count = count_time.Text;
            if (form_data1.modificar(forms) > 0)
            {
                MessageBox.Show("registro exitoso");
                this.Close();
            }
        }
        private void cargardatos()
        {
            forms = form_data1.buscarporid(_idform);
            if (forms.id_form > 0)
            {
                textBox1.Text = forms.id_form.ToString();
                fore.Text = forms.Id_employee_fore.ToString();
                salario.Text = forms.salary;
                bonus_salary.Text = forms.bonus_salary;
                desc_salary.Text = forms.discount_salary;
                count_time.Text = forms.time_count;
            }
            else
            {
                MessageBox.Show("ocurrio un problema al cargar datos");
                this.Close();
            }
        }
        private void planilla_modificar_Load(object sender, EventArgs e)
        {
            cargardatos();
        }

        private void fore_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
