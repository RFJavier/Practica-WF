﻿using employecountsystem.bussines;
using employecountsystem.entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace employecountsystem
{
    public partial class planilladatos : Form
    {
        public planilladatos()
        {
            InitializeComponent();
        }
        form forms = new form();
        public int _idform = 0;
        private void cargardatos()
        {
            forms = form_data1.buscarporid(_idform);
            if (forms.id_form >= 0)
            {
                dataGridView1.DataSource = form_data1.obtenertodos();
            }
            else
            {
                MessageBox.Show("ocurrio un problema al cargar datos");
                this.Close();
            }
        }
        private void planilladatos_Load(object sender, EventArgs e)
        {
            cargardatos();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
