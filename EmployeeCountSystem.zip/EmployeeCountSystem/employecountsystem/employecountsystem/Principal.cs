﻿using employecountsystem.bussines;
using employecountsystem.entities;
using employecountsystem.Utilidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace employecountsystem
{
    public partial class Principal : Form
    {
        public Principal()
        {
            InitializeComponent();
        }
        employees employees = new employees();
        public int _idemployee;
        public string _id;


        private void Index_Load(object sender, EventArgs e)
        {

            mostrar();

        }

        private void mostrar()
        {
            dataGridView1.DataSource = employee_data1.obtenertodos();
        }
        private void ModifyEmploye_Click(object sender, EventArgs e)
        {
            int id = uformulario.obtenerdgrid(dataGridView1);
            if (id > 0)
            {
                Modificar_Datos_de_Usuario datos_ = new Modificar_Datos_de_Usuario();
                datos_.StartPosition = FormStartPosition.CenterScreen;
                datos_._idemployee = id;
                datos_.ShowDialog();
                mostrar();

            }
            else
            {
                MessageBox.Show("debe seleccionar un registro");
            }

        }

        private void nuevoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            index datos_ = new index();
            datos_.StartPosition = FormStartPosition.CenterScreen;
            datos_.ShowDialog();
        }

        private void baseDeDatosToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Datos datos_ = new Datos();
            datos_.StartPosition = FormStartPosition.CenterScreen;
            datos_.ShowDialog();
        }

        private void principalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            index1 datos_ = new index1();
            datos_.StartPosition = FormStartPosition.CenterScreen;
            datos_.ShowDialog();
        }


        private void EmployeeId_TextChanged(object sender, EventArgs e)
        {


        }



        private void SearchById_Click(object sender, EventArgs e)
        {



        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Eliminar_Click(object sender, EventArgs e)
        {
            int id = uformulario.obtenerdgrid(dataGridView1);
            if (id > 0)
            {
                if (MessageBox.Show("desea eliminar el registro?", "eliminar",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                {
                    if (employee_data1.eliminar(new employees { Id_employee = id }) > 0)
                    {
                        MessageBox.Show("registro eliminado");
                        mostrar();
                    }
                    else
                    {
                        MessageBox.Show("No se ah eliminado el registro");
                    }

                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            index datos_ = new index();
            datos_.StartPosition = FormStartPosition.CenterScreen;
            datos_.ShowDialog();
        }

        private void nuevoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Planilla datos_ = new Planilla();
            datos_.StartPosition = FormStartPosition.CenterScreen;
            datos_.ShowDialog();
        }

        private void baseDeDatosToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            planilladatos datos_ = new planilladatos();
            datos_.StartPosition = FormStartPosition.CenterScreen;
            datos_.ShowDialog();
        }
    }
}
