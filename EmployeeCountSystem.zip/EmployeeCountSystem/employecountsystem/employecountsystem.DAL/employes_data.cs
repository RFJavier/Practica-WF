﻿using employecountsystem.entities;

using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace employecountsystem.DAL
{
    public class employes_data
    {
        public static int save_employee(employees pdata)
        {
            string consulta = @"INSERT INTO employes_data(firstname, lastname, dui, phone, job, contract_date, salary) VALUES (@firstname, @lastname, @dui, @phone, @job, @contract_date, @salary)";
            SqlCommand comando = Commondb.obtenercomando();
            comando.CommandText = consulta;

            comando.Parameters.AddWithValue("@firstname", pdata.firstname);
            comando.Parameters.AddWithValue("@lastname", pdata.lastname);
            comando.Parameters.AddWithValue("@dui", pdata.DUI);
            comando.Parameters.AddWithValue("@phone", pdata.phone);
            comando.Parameters.AddWithValue("@job", pdata.job);
            comando.Parameters.AddWithValue("@contract_date", pdata.contract_date);
            comando.Parameters.AddWithValue("@salary", pdata.salary);
            return Commondb.Ejecutarcomando(comando);

        }

        public static int modify_employee(employees pdata)
        {
            string consulta = "UPDATE employes_data SET firstname = @firstname, lastname = @lastname, dui = @dui, phone = @phone, job = @job, contract_date = @contract_date, salary = @salary WHERE id_employe = @id_employe";
            SqlCommand comando = Commondb.obtenercomando();
            comando.CommandText = consulta;
            comando.Parameters.AddWithValue("@firstname", pdata.firstname);
            comando.Parameters.AddWithValue("@lastname", pdata.lastname);
            comando.Parameters.AddWithValue("@dui", pdata.DUI);
            comando.Parameters.AddWithValue("@phone", pdata.phone);
            comando.Parameters.AddWithValue("@job", pdata.job);
            comando.Parameters.AddWithValue("@contract_date", pdata.contract_date);
            comando.Parameters.AddWithValue("@salary", pdata.salary);
            comando.Parameters.AddWithValue("@id_employe", pdata.Id_employee);
            return Commondb.Ejecutarcomando(comando);

        }
        public static int delete_employee(employees pdata)
        {
            string consulta = "DELETE FROM employes_data WHERE id_employe = @id_employe";
            SqlCommand comando = Commondb.obtenercomando();
            comando.CommandText = consulta;
            comando.Parameters.AddWithValue("@id_employe", pdata.Id_employee);
            return Commondb.Ejecutarcomando(comando);

        }
        public static List<employees> obtainall()
        {
            //string consulta = "SELECT TOP 10 e.id_employe, e.firstname, e.lastname, e.lastname, e.dui, e.phone, e.phone, e.job, e.contract_date, e.salary FROM employes_data e ";
            string consulta = "SELECT * FROM employes_data";
            SqlCommand comando = Commondb.obtenercomando();
            comando.CommandText = consulta;
            SqlDataReader reader = Commondb.Ejecutarcomandoreader(comando);
            List<employees> listemployee = new List<employees>();
            while (reader.Read())
            {
                employees employee = new employees();

                employee.Id_employee = reader.GetInt32(0);
                employee.firstname = reader.GetString(1);
                employee.lastname = reader.GetString(2);
                employee.DUI = reader.GetString(3);
                employee.phone = reader.GetString(4);
                employee.job = reader.GetString(5);
                employee.contract_date = reader.GetString(6);
                employee.salary = reader.GetString(7);
                listemployee.Add(employee);
            }
            return listemployee;
        }
        public static employees searchbyid(int pid_employee)
        {
            string consulta = "SELECT e.id_employe, e.firstname, e.lastname, e.dui, e.phone, e.job, e.contract_date, e.salary FROM employes_data e WHERE id_employe = @id_employe";
            SqlCommand comando = Commondb.obtenercomando();
            comando.CommandText = consulta;
            comando.Parameters.AddWithValue("@id_employe", pid_employee);
            SqlDataReader reader = Commondb.Ejecutarcomandoreader(comando);
            employees employee= new employees();
            while (reader.Read())
            {

                employee.Id_employee = reader.GetInt32(0);
                employee.firstname = reader.GetString(1);
                employee.lastname = reader.GetString(2);
                employee.DUI = reader.GetString(3);
                employee.phone = reader.GetString(4);
                employee.job = reader.GetString(5);
                employee.contract_date = reader.GetString(6);
                employee.salary = reader.GetString(7);
           
            }
            return employee;
            
        }
    }
}
