﻿using employecountsystem.entities;

using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Threading.Tasks;

namespace employecountsystem.DAL
{
    public class form_data
    {
        public static int save_form(form pdata)
        {
            string consulta = @"INSERT INTO form_employe(salary, bonus_salary, discount_salary, time_count) VALUES (@salary, 
            @bonus_salary, @discount_salary, @time_count)";
            SqlCommand comando = Commondb.obtenercomando();
            comando.CommandText = consulta;

            comando.Parameters.AddWithValue("@salary", pdata.salary);
            comando.Parameters.AddWithValue("@bonus_salary", pdata.bonus_salary);
            comando.Parameters.AddWithValue("@discount_salary", pdata.discount_salary);
            comando.Parameters.AddWithValue("@time_count", pdata.time_count);
           
            return Commondb.Ejecutarcomando(comando);

        }
        public static int modify_form(form pdata)
        {
            string consulta = "UPDATE form_employe SET salary = @salary, bonus_salary = @bonus_salary, discount_salary = @discount_salary, time_count = @time_count WHERE id_form = @id_form";
            SqlCommand comando = Commondb.obtenercomando();
            comando.CommandText = consulta;
            comando.Parameters.AddWithValue("@id_form_fore", pdata.Id_employee_fore);
            comando.Parameters.AddWithValue("@salary", pdata.salary);
            comando.Parameters.AddWithValue("@bonus_salary", pdata.bonus_salary);
            comando.Parameters.AddWithValue("@discount_salary", pdata.discount_salary);
            comando.Parameters.AddWithValue("@time_count", pdata.time_count);
            comando.Parameters.AddWithValue("@id_form", pdata.id_form);
            return Commondb.Ejecutarcomando(comando);

        }
        public static int delete_form(form pdata)
        {
            string consulta = "DELETE FROM form_employe WHERE id_form = @id_form";
            SqlCommand comando = Commondb.obtenercomando();
            comando.CommandText = consulta;
            comando.Parameters.AddWithValue("@id_form", pdata.id_form);
            return Commondb.Ejecutarcomando(comando);

        }
        public static List<form> obtainall()
        {
            //string consulta = "SELECT TOP 10 e.id_employe, e.firstname, e.lastname, e.lastname, e.dui, e.phone, e.phone, e.job, e.contract_date, e.salary FROM employes_data e ";
            string consulta = "SELECT * FROM form_employe";
            SqlCommand comando = Commondb.obtenercomando();
            comando.CommandText = consulta;
            SqlDataReader reader = Commondb.Ejecutarcomandoreader(comando);
            List<form> listemployee = new List<form>();
            while (reader.Read())
            {
                form form = new form();
                form.id_form = reader.GetInt32(0);
                
                form.salary = reader.GetString(2);
                form.bonus_salary = reader.GetString(3);
                form.discount_salary = reader.GetString(4);
                form.time_count = reader.GetString(5);
                listemployee.Add(form);
            }
            return listemployee;
        }
        public static form searchbyid(int pid_form)
        {
            string consulta = "SELECT f.id_form, f.salary, f.bonus_salary, f.discount_salary, f.time_count FROM form_employe f WHERE id_form = @id_form";
            SqlCommand comando = Commondb.obtenercomando();
            comando.CommandText = consulta;
            comando.Parameters.AddWithValue("@id_form", pid_form);
            SqlDataReader reader = Commondb.Ejecutarcomandoreader(comando);
            form forms = new form();
            while (reader.Read())
            {

                forms.id_form = reader.GetInt32(0);
                
                forms.salary = reader.GetString(1);
                forms.bonus_salary = reader.GetString(2);
                forms.discount_salary = reader.GetString(3);
                forms.time_count = reader.GetString(4);
                

            }
            return forms;

        }
    }
}