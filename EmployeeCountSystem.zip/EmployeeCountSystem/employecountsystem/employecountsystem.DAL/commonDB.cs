﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace employecountsystem.DAL
{
    public class Commondb
    {
        const string Strconexion = @"Data Source=RJPC;Initial Catalog=workersdatabase;Integrated Security=True";

        private static SqlConnection Obtenerconexion()
        {
            SqlConnection connection = new SqlConnection(Strconexion);
            connection.Open();
            return connection;
        }
        public static SqlCommand obtenercomando()
        {
            SqlCommand command = new SqlCommand();
            command.Connection = Obtenerconexion();
            return command;
        }
        public static int Ejecutarcomando(SqlCommand pcomando)
        {
            int resultado = pcomando.ExecuteNonQuery();
            pcomando.Connection.Close();
            return resultado;
        }
        public static SqlDataReader Ejecutarcomandoreader(SqlCommand pcomando)
        {
            SqlDataReader reader = pcomando.ExecuteReader(CommandBehavior.CloseConnection);

            return reader;

        }
    }
}