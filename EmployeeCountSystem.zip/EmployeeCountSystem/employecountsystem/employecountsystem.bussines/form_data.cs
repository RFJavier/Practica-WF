﻿using employecountsystem.DAL;
using employecountsystem.entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace employecountsystem.bussines
{
    public class form_data1
    {
        public static int save(form pdata)
        {
            return form_data.save_form(pdata);
        }
        public static int modificar(form pdata)
        {
            return form_data.modify_form(pdata);
        }
        public static int eliminar(form pdata)
        {
            return form_data.delete_form(pdata);
        }
        public static List<form> obtenertodos()
        {
            return form_data.obtainall();
        }
        public static form buscarporid(int pid_form)
        {
            return form_data.searchbyid(pid_form);

        }
    }
}
