﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using employecountsystem.DAL;
using employecountsystem.entities;

namespace employecountsystem.bussines
{
    public class employee_data1
    {
        public static int save(employees pdata)
        {
            return employes_data.save_employee(pdata);
        }
        public static int modificar(employees pdata)
        {
            return employes_data.modify_employee(pdata);
        }
        public static int eliminar(employees pdata)
        {
            return employes_data.delete_employee(pdata);
        }
        public static List<employees> obtenertodos()
        {
            return employes_data.obtainall();
        }
        public static employees buscarporid(int pid_employe)
        {
            return employes_data.searchbyid(pid_employe);

        }
    }
}
