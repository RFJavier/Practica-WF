﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace employecountsystem.entities
{
    public class employees
    {
        [Key]
        public int Id_employee { get; set; }



        public string firstname { get; set; }
        public string lastname { get; set; }
        public string DUI { get; set; }
        public string phone { get; set; }
        public string job { get; set; }
        public string contract_date { get; set; }
        public string salary { get; set; }
    }
}
