﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using employecountsystem.entities;

namespace employecountsystem.entities
{
    public class form
    {
        [Key]
        public int id_form { get; set; }
        [ForeignKey(("id_employee_fore"))]
        [Display(Name = "id_employee_fore")]
        public int Id_employee_fore { get; set; }

        public string salary { get; set; }
        public string bonus_salary {get; set;}
        public string discount_salary { get; set;}
        public string time_count { get; set; }

        [NotMapped]
        public int Top_Aux { get; set; }
        public List<employees> employes_Datas{ get; set; }



    }
}